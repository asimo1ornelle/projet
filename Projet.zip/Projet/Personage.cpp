#include "Personage.h"
#include <iostream>
#include <fstream>
#include <string>
#include "Date_time.h"

using namespace std;

Personage::Personage(){
    c_name = "ASIMO";
    c_surname = "Ornelle";
    c_age = 27;
}

void Personage::register_file(){
    string file_register("file_register.txt");
    ofstream file(file_register.c_str(), ios::app);

    if(file)
    {

        file <<c_name<<" "<<c_surname<<" "<<c_age<<" years old"<<endl;
        file <<c_time.get_date()<<endl;
    }
    else{
        cout<<"Error"<<endl;
    }

}
bool Personage::more_small_than(Personage const& b)const{
        return c_age < b.c_age;
}
  bool Personage::operator<(Personage const& b){
    return more_small_than(b);
}
bool Personage::bigger_than(Personage const& b)const{
        return c_age > b.c_age;
}
bool Personage::operator>(Personage const& b){
    return bigger_than(b);
}
bool Personage::equal_to(Personage const& b)const{
        return c_age ==b.c_age;
}
bool Personage::operator ==(Personage const& b){
    return equal_to(b);
}

void Personage::set_data(){
    cin>>c_name;
    cin>>c_surname;
    cin>>c_age;
}
