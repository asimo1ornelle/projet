#include <iostream>
#include"Personage.h"
#include <fstream>
#include "Administrator.h"
#include "Employes.h"
using namespace std;

int main()
{
    cout << "Hello world!" << endl;
    int answer;
cout<<"what do personage you want create?"<<endl;
int rep;
Administrator admin;
 Employes empl;
    do{
        answer = 0;
        while(answer != 1 && answer != 2 ){
        cout<<"Put 1 for Administrator"<<endl;
        cout <<"Put 2 for Employes"<<endl;
        cin>>answer;
    }

    if(answer == 1){

    int x,y;
    do {
        cout<<"Choose one act"<<endl;
        cout<<"Press 0 to display information administrator"<<endl;
        cout<<"Press 1 to register information administrator"<<endl;
        cout<<"Press 2 to display file"<<endl;
        cout<<"Press 3 to put data"<<endl;
        cin>>x;
        switch(x){
        case 0:
        admin.display_data();
        break;
        case 1:
        admin.register_file();
        break;
        case 2:
        admin.display_file();
        break;
        case 3:
        admin.set_data();
        break;
    }
    cout<<"Do you want yet do one act?"<<endl;
    cout<<"Press 4 for yes"<<endl;
    cin>>y;
    }while(y == 4);


    }
    else{

        int x,y;
        do {
        cout<<"Press 0 to display information administrator"<<endl;
        cout<<"Press 1 to register information administrator"<<endl;
        cout<<"Press 2 to put data"<<endl;
        cin>>x;
        switch(x){
        case 0:
        empl.display_data();
        break;
        case 1:
        empl.register_file();
        break;

        case 2:
        empl.set_data();
        break;
    }
    cout<<"Do you want yet do one act?"<<endl;
    cout<<"Press 3 for yes"<<endl;
    cin>>y;
    }while(y == 3);
    }
    cout<<"Do you want to do other act? Press 0 for yes"<<endl;

    cin>>rep;
    }while(rep ==0);
    if(empl<admin){
        cout<<"administrator is older than empll"<<endl;}
    else if(empl>admin){
        cout<<"administrator is less old than empl"<<endl;}
    else{
        cout<<"administrator is equal to empl"<<endl;
    }

    return 0;
}
