#ifndef PERSONAGE_H_INCLUDED
#define PERSONAGE_H_INCLUDED
#include <string>
#include "Date_time.h"
class Personage{
public:
    Personage();

    void register_file();
    void set_data();
    bool more_small_than(Personage const& b) const;
    bool operator<( Personage const& b);

    bool bigger_than(Personage const& b) const;
    bool operator>( Personage const& b);


    bool equal_to(Personage const& b) const;
    bool operator==( Personage const& b);


protected:
    std::string c_name;
    std::string c_surname;
    int c_age;
    Date_time c_time;
};


#endif // PERSONAGE_H_INCLUDED
