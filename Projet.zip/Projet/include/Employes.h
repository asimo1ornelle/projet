#ifndef EMPLOYES_H
#define EMPLOYES_H
#include "../Personage.h"

class Employes : public Personage
{
    public:
        void display_data();
        void set_data();
};


#endif // EMPLOYES_H
