#ifndef ADMINISTRATOR_H
#define ADMINISTRATOR_H
#include <../Personage.h>

class Administrator : public Personage
{
    public:
        void display_file();
        void display_data();
        void set_data();
};

#endif // ADMINISTRATOR_H
