#ifndef DATE_TIME_H
#define DATE_TIME_H
#include <ctime>

class Date_time
{
    public:
        void display_date();
        char* get_date();
    private:
       time_t t;
       char* c_date;

};

#endif // DATE_TIME_H
