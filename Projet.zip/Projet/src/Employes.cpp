#include "Employes.h"
#include <iostream>
using namespace std;
void Employes::display_data(){
    cout<<c_name<<" "<<c_surname<<" "<<c_age<<" years old"<<endl;
    c_time.display_date();
}
void Employes::set_data(){
    cout<<"Employe : "<<endl;
    cout<<"This name : "<<endl;
    cin>>c_name;
    cout<<"This surname : "<<endl;
    cin>>c_surname;
    cout<<"This age : "<<endl;
    cin>>c_age;
}
