#include "Administrator.h"
#include <fstream>
#include <iostream>
using namespace std;
#include "../Personage.h"
void Administrator::display_file(){
    ifstream file_read("file_register.txt");
    if(file_read){
        string x;
        while(getline(file_read,x))
        {
            cout<<x<<endl;
        }
    }
    else{
        cout<<"Error, it's only administrator"<<endl;
    }
}
void Administrator::display_data(){
    cout<<c_name<<" "<<c_surname<<" "<<c_age<<" years old"<<endl;
    c_time.display_date();
}
void Administrator::set_data(){
    cout<<"Administrator : "<<endl;
    cout<<"This name : "<<endl;
    cin>>c_name;
    cout<<"This surname : "<<endl;
    cin>>c_surname;
    cout<<"This a : "<<endl;
    cin>>c_age;
}
