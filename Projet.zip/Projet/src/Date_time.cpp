#include "Date_time.h"
#include <iostream>

#include <ctime>
using namespace std;

void Date_time::display_date(){
    t = time(0);
    c_date = ctime(&t);
    cout<<c_date<<endl;
}
char* Date_time::get_date(){
    return c_date;
}
